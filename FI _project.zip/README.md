# AI-Enhanced Secure Web Application

## Overview
This project is a web application designed to demonstrate common web security vulnerabilities and how they can be mitigated using traditional security measures combined with Artificial Intelligence (AI). It is divided into two main versions:

1. **Vulnerable Version**: Contains intentional security flaws such as:
   - SQL Injection
   - Cross-Site Scripting (XSS)
   - Cross-Site Request Forgery (CSRF)
   - Insecure file uploads
2. **Secure Version**: Implements protections and security best practices using both server-side validation and AI-enhanced detection.

---

## Features
- User authentication and role management
- Vulnerability simulation for educational purposes
- AI-based security alerts and anomaly detection
- Interactive dashboard for monitoring security incidents
- Logging of user activities for auditing

---

## Folder Structure
AI-Enhanced Secure Web Application/
│
├── Assets/ # CSS, JS, images
├── Secure/ # Secure version of the app
├── Vulnerable/ # Vulnerable version of the app
├── logs/ # Text logs for monitoring
├── index.php # Landing page
└── README.md # Project documentation

---

## Requirements
- PHP 8+
- MySQL 5.7+ (or MariaDB)
- XAMPP / LAMP / WAMP server
- Composer (optional, for AI integration)

---

## Installation
1. Clone or download this repository into your XAMPP/LAMP `htdocs` folder.
2. Import the database (provided in `/Database`) using phpMyAdmin.
3. Configure `config.php` with your database credentials.
4. Start Apache and MySQL services.
5. Open your browser and navigate to `http://localhost/AI-Enhanced Secure Web Application/`.

---

## Usage
- Open `index.php` to choose between the secure and vulnerable version.
- Test vulnerabilities in the vulnerable version to understand security risks.
- Explore AI detection alerts in the secure version.

---

## Contributing
Feel free to submit issues or pull requests to enhance security features or improve the AI functionality.

---

## License
This project is for **educational purposes only**.
